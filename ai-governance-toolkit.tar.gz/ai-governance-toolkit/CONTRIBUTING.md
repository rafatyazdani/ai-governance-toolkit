# Contributing to ai-governance-toolkit

Thank you for your interest in contributing. This toolkit is built by practitioners for practitioners — contributions that make it more accurate, more useful, or more complete are welcome.

---

## What we're looking for

- **Framework updates** — regulatory changes, new guidance, updated standards
- **New templates** — governance documents covering gaps in the current set
- **Tool enhancements** — new scoring models, output formats, or integrations
- **Assessment guides** — additional assessment frameworks (model risk, bias, third-party)
- **Bug fixes** — especially in the Python tools (scoring logic, edge cases)
- **Real-world validation** — if you've used these templates in practice and found issues

---

## What we're not looking for (right now)

- Vendor-specific content that promotes commercial products
- Templates that haven't been validated against actual governance requirements
- Major structural rewrites without prior discussion

---

## How to contribute

1. **Fork** the repo and create a branch: `git checkout -b feature/your-change`
2. **Make your changes** — follow the style conventions below
3. **Test Python tools** — run `python tool.py --interactive` and verify output
4. **Submit a pull request** with a clear description of what changed and why

For significant changes, open an issue first to discuss the approach.

---

## Style conventions

**Markdown:**
- Use sentence case for all headings
- Use tables for structured comparisons
- Include a "Practitioner note" callout wherever you have real-world insight that isn't in the official guidance

**Python:**
- Python 3.9+ compatible
- No third-party dependencies in core tools (optional dependencies only, clearly documented)
- Interactive mode + JSON input for all tools
- Markdown report output as default

**Templates:**
- All templates must be immediately usable — no lorem ipsum placeholders without clear instructions
- Include a change log section at the bottom
- Attribution line: `*Template from [ai-governance-toolkit] | Apache 2.0*`

---

## License

By contributing, you agree that your contributions will be licensed under the Apache 2.0 license.
