# EU AI Act — Practitioner Guide

> Regulation (EU) 2024/1689. Entered into force August 2024. World's first comprehensive AI regulation with binding risk-based obligations.

---

## Overview

The EU AI Act applies a **risk-tiered, product-safety-style regulatory model** to AI systems. Unlike NIST AI RMF (voluntary) or ISO 42001 (management system), the EU AI Act is **binding law** with significant financial penalties for non-compliance.

**Who is affected:**
Even if your company is not EU-based, the Act applies if your AI system is **placed on the EU market** or **used to affect persons in the EU**. Global companies cannot opt out.

**Key penalty exposure:**
- Up to €35M or 7% of global annual turnover for prohibited AI violations
- Up to €15M or 3% for high-risk AI violations
- Up to €7.5M or 1.5% for minor violations

---

## Risk Tiers

### Unacceptable Risk — PROHIBITED

AI systems with unacceptable risk are **banned outright**.

| Prohibited system | Notes |
|-------------------|-------|
| Social scoring by public authorities | Government-operated behavioral scoring |
| Real-time remote biometric ID in public spaces | With narrow exceptions for law enforcement |
| Subliminal manipulation causing harm | Exploitation of vulnerabilities |
| Emotion recognition in workplace/education | High civil liberties concern |

**Practitioner action:** Audit your AI use case inventory for any systems that approach these categories. Document why they do not qualify as prohibited. When in doubt, legal review required.

---

### High Risk

High-risk AI systems are **permitted but heavily regulated** — requiring conformity assessments, technical documentation, human oversight, and registration.

**High-risk domains (Annex III):**
- Biometric identification and categorization
- Critical infrastructure management
- Education and vocational training (e.g., exam scoring)
- Employment and HR (e.g., resume screening, performance monitoring)
- Essential private and public services (credit scoring, benefits eligibility)
- Law enforcement
- Migration and border control
- Administration of justice

**Obligations for high-risk AI providers:**
- [ ] Risk management system (ongoing, not one-time)
- [ ] Data governance and quality controls
- [ ] Technical documentation (system card equivalent)
- [ ] Transparency and instructions for use
- [ ] Human oversight mechanisms
- [ ] Accuracy, robustness, and cybersecurity standards
- [ ] Conformity assessment (self-assessment or third-party)
- [ ] Registration in EU AI database
- [ ] Post-market monitoring system

**Practitioner note:** "Provider" vs. "deployer" matters. If your organization customizes or fine-tunes a third-party foundation model for a high-risk use case, you may be classified as a **provider**, not merely a deployer — triggering the full compliance burden.

---

### Limited Risk — Transparency Obligations

AI systems with limited risk are **permitted** but must meet transparency requirements.

| System | Obligation |
|--------|-----------|
| Chatbots / conversational AI | Disclose that users are interacting with AI |
| Deepfakes and synthetic media | Label as AI-generated |
| Emotion recognition systems | Notify users |

---

### Minimal Risk

The vast majority of AI systems (spam filters, AI in video games, recommendation systems) fall in this tier. **No specific obligations**, but voluntary codes of conduct are encouraged.

---

## GPAI (General Purpose AI) Models

The Act introduced specific obligations for **General Purpose AI (GPAI) models** — foundation models like GPT-4, Claude, Gemini.

| Category | Obligation |
|----------|-----------|
| All GPAI providers | Technical documentation, copyright policy, training data summary |
| Systemic-risk GPAI (>10^25 FLOPs) | Adversarial testing, incident reporting, cybersecurity measures |

**Practitioner implication:** If your organization uses a GPAI model API, the model provider bears primary GPAI obligations — but you bear obligations as a **deployer** for your use case's risk tier.

---

## Implementation Timeline

| Date | Milestone |
|------|-----------|
| Aug 2024 | Act enters into force |
| Feb 2025 | Prohibited AI provisions apply |
| Aug 2025 | GPAI obligations and governance provisions apply |
| Aug 2026 | High-risk AI (Annex III) obligations apply |
| Aug 2027 | Full Act applies, including Annex I high-risk systems |

---

## Compliance Roadmap for Organizations

**Step 1: AI use case inventory** (immediately)
Map all AI use cases to the four risk tiers.

**Step 2: Prohibited AI audit** (before Feb 2025 — now urgent)
Confirm no systems qualify as prohibited. Document reasoning.

**Step 3: GPAI governance** (before Aug 2025)
For each GPAI API in use, document: provider obligations met, your deployer obligations, use case risk tier.

**Step 4: High-risk compliance program** (before Aug 2026)
For each high-risk use case: conformity assessment plan, technical documentation, human oversight design, registration plan.

**Step 5: Ongoing monitoring**
Post-market monitoring, incident reporting procedures, annual review.

---

## Mapping EU AI Act to NIST AI RMF

| EU AI Act Obligation | NIST AI RMF Function | Toolkit Resource |
|---------------------|---------------------|-----------------|
| Risk management system | MAP, MEASURE | [AI Risk Register](../templates/ai-risk-register.md) |
| Technical documentation | GOVERN, MAP | [Use Case Intake](../templates/use-case-intake.md) |
| Human oversight | MANAGE | [Maturity Scorecard](../assessments/maturity-scorecard.md) |
| Conformity assessment | MEASURE | [Model Risk Assessment](../assessments/model-risk.md) |

---

## Resources

- [EU AI Act full text (EUR-Lex)](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:32024R1689)
- [EU AI Office](https://digital-strategy.ec.europa.eu/en/policies/ai-office)
- [High-Level Summary — A&O Shearman](https://www.aolaw.com)

---

*See also: [NIST AI RMF](NIST-AI-RMF.md) | [ISO 42001](ISO-42001.md) | [Framework Comparison](comparison.md)*
